import pyLoRaWAN

# 初始化LoRaWAN连接，根据实际情况修改参数
lora = pyLoRaWAN.LoRaWAN(server_address='网关配置的服务器地址', port=网关配置的端口)
# 建立连接
lora.connect()

while True:
    # 接收数据
    received_data = lora.receive_data()
    if received_data:
        print(f"Received data: {received_data}")